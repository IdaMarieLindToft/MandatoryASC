﻿using System;

namespace TestProject
{
   public class Program
    {
        static void Main(string[] args)
        {
            Worker w1 = new Worker();
            w1.Work();

        }
    }
}
